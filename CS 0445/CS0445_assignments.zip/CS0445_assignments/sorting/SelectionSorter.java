/**
 * Implementation of SelectionSort
 * @author Daesang Yoon
 *
 */
public class SelectionSorter implements IntSorter {
    private int[] array = null;
    private int moves = 0;
    private long startTime = 0;
    private long endTime = 0;

    public void init(int[] a){
        this.array = a;
        moves = 0;

    }

    public void sort( ){
        startTime = System.nanoTime();
        for(int i =0; i < array.length-1; i++){
            int minIndex = getMinIndex(array, i);
                swap(array, i, minIndex);
                moves++;
        }
        endTime = System.nanoTime();
    }

    private void swap(int[] a, int i, int j){
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;

    }

    private int getMinIndex(int[] a, int i){
        int min = i;
        for(int k = i+1; k < a.length; k++){
            if(a[k] < a[min]){
                min = k;
            }
        }
        return min;
    }


    public int getMoves() {
        return moves;
    }

    @Override
    public long getSortTime() {
        return endTime - startTime;
    }
}
