
/**
 * Created by 5years on 2/25/2017.
 */

import org.junit.Test;

import java.util.Random;
import static org.junit.Assert.*;

public class MergeSorterTest {
        private int[] numbers;
        private final static int SMALL_SIZE = 10;
        private final static int LARGE_SIZE = 100;
        private final static int MAX = 20;

    @Test
    public void testSort() {
        numbers = new int[SMALL_SIZE];
        Random generator = new Random();
        for (int k = 0; k < numbers.length; k++){
            numbers[k] = generator.nextInt(MAX);
        }

        MergeSorter firstSorter = new MergeSorter();
        firstSorter.init(numbers);
        firstSorter.sort();
        System.out.println("Sorted Time:" + firstSorter.getSortTime());
        System.out.println("Total Moves:" + firstSorter.getMoves());

        for(int i = 0; i < numbers.length - 1; i++){
            if (numbers[i] > numbers[i+1]) {
                fail("This is not supposed to be happen");
            }
        }
        assertTrue(true);
    }

    @Test
    public void testRepeat() {
        for(int i = 0; i < 10; i++){
            numbers = new int[SMALL_SIZE];
            Random generator = new Random();
            for (int k = 0; k < numbers.length; k++){
                numbers[k] = generator.nextInt(MAX);
            }

            MergeSorter sorter = new MergeSorter();
            sorter.init(numbers);
            sorter.sort();
            System.out.println("Sorted Time:" + sorter.getSortTime());
            System.out.println("Total Moves:" + sorter.getMoves());

            for(int j = 0; j < numbers.length - 1; j++){
                if(numbers[j] > numbers[j+1]){
                    fail("Not supposed to be not sorted");
                }
            }
            assertTrue(true);
        }
    }

    @Test
    public void testLargeSort(){
        numbers = new int[LARGE_SIZE];
        Random generator = new Random();
        for(int i = 0; i < numbers.length; i++){
            numbers[i] = generator.nextInt(MAX);
        }

        MergeSorter sorter = new MergeSorter();
        sorter.init(numbers);
        sorter.sort();
        System.out.println("Sorted Time:" + sorter.getSortTime());
        System.out.println("Total Moves:" + sorter.getMoves());

        for(int i = 0; i < numbers.length - 1; i++){
            if (numbers[i] > numbers[i+1]) {
                fail("This is not supposed to be happen");
            }
        }
        assertTrue(true);

    }



}