/**
 * Created by 5years on 2/24/2017.
 */
public class MergeSorter implements IntSorter{
    private int[] array = null;
    private int moves = 0;
    private long startTime = 0;
    private long endTime = 0;

    public void init(int[] a){
        this.array = a;
        moves = 0;
    }

    public void sort() {
        startTime = System.nanoTime();
        int[] temp = new int[array.length];
        mergeSort(array, temp, 0, array.length/2, array.length);
        endTime = System.nanoTime();
    }

    private void mergeSort(int[] a, int[] temp, int begin, int mid, int end){
        if(end-mid > 1 || mid-begin > 1){
            mergeSort(a, temp, begin, (mid + begin) / 2, mid);
            mergeSort(a, temp, mid, (end + mid) / 2, end );

        }
        merge(a, temp, begin, mid, end);

    }

    private void merge(int[] a, int[] temp, int begin, int mid, int end){
        int b1 = begin;
        int b2 = mid;
        int index = 0;

        while(b1 < mid && b2 < end) {
            if (a[b1] <= a[b2]) {
                temp[index] = a[b1];
                index++;
                b1++;
                moves++;
            } else {
                temp[index] = a[b2];
                index++;
                b2++;
                moves++;
            }

        }

            for(int i = b1; i < mid; i++){
                temp[index] = a[i];
                index++;
                moves++;
            }
        /*
            for(int i = b2; i < end; i++){
                temp[index] = a[i];
                index++;
            }
        */
        System.arraycopy(temp,0,a, begin, index);
    }


    public int getMoves(){
        return moves;
    }

    public long getSortTime(){
        return endTime - startTime;
    }
}
