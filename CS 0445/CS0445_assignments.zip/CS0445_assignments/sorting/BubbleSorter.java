/**
 *  Implementation of BubbleSort
 *
 */
public class BubbleSorter implements IntSorter{
    private int[] array = null;
    private int moves = 0;
    private long startTime = 0;
    private long endTime = 0;

    public void init(int[] a) {
        this.array = a;
        moves = 0;
    }

    @Override
    public void sort() {
        startTime = System.nanoTime();
        int index;
        boolean isNotSorted = true;
        while(isNotSorted){
            isNotSorted = false;
            for(index = 0; index < array.length - 1; index++){
                if(array[index] > array[index + 1]){
                    swap(array, index, index +1);
                    isNotSorted = true;
                    moves++;
                }
            }
        }
        endTime = System.nanoTime();
    }

    private void swap(int[] a, int i, int j){
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    @Override
    public int getMoves() {
        return moves;
    }

    @Override
    public long getSortTime() {
        return endTime - startTime;
    }
}
