public interface StringIterator {
  public String next();
  public boolean hasNext();
}