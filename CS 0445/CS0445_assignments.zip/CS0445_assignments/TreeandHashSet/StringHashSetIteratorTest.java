public class StringHashSetIteratorTest {
	public static void main(String[] args)
	{
		StringHashSet h = new StringHashSet();
		h.add("a");
		iterate(h);

		h = new StringHashSet(); //adjacent single nodes
		h.add("a");
		h.add("b");
		iterate(h);

		h = new StringHashSet(); //non-adjacent single nodes
		h.add("a");
		h.add("r");
		iterate(h);

		h = new StringHashSet(); //a two-member chain
		h.add("a");
		h.add("x");
		iterate(h);

		h = new StringHashSet(); //a two-member chain
		h.add("a");
		h.add("x");
		iterate(h);

		h = new StringHashSet(); //no values
		StringIterator i = h.iterator();
		System.out.println(i.hasNext() +" "+ (i.next() == null));

		h = new StringHashSet(); //a two-member chain preceded by a single node
		h.add("t");
		h.add("a");
		h.add("x");
		h.add("f");
		iterate(h);

		h = new StringHashSet(); //a three-member chain flanked by single nodes
		h.add("t");
		h.add("a");
		h.add("x");
		h.add("J");
		h.add("A");
		iterate(h);
	}

	public static void iterate(StringHashSet h)
	{
		StringIterator i = h.iterator();
		while (i.hasNext())
		{
			System.out.print(i.next()+" ");
		}
		System.out.println();
	}
}