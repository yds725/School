import org.junit.Test;

public class StringTreeSetTest {
    @Test
    public void testIterator() {
        StringTreeSet set = new StringTreeSet();
        /*
        for (int i = 10; i < 20; i++) {
            set.add(Integer.toString(i));
        }
        */
        set.add("A");
        set.add("B");
        set.add("C");
        set.add("D");
        set.add("E");
        set.add("F");
        set.add("G");
        set.add("H");
        set.add("I");
        set.add("J");
        set.add("K");
        set.add("L");
        set.add("M");
        set.add("N");
        set.add("O");

        StringIterator i = set.iterator();

        while (i.hasNext()){
            System.out.println("Value: "+i.next() + " ");
        }
    }
}