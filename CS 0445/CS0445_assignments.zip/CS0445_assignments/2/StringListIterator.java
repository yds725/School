public interface StringListIterator {
  public String next();
  public boolean hasNext();
}