import java.util.Random;

import static org.junit.Assert.fail;




public class MaxHeapTest {
    private long[] numbers;
    private final static int SMALL_SIZE = 9;
    private final static int LARGE_SIZE = 100;
    private final static int MAX = 10;

    @org.junit.Test
    public void heapsortTest() {

        numbers = new long[SMALL_SIZE];
        Random generator = new Random();
        for(int i = 0; i < numbers.length; i++){
          numbers[i] = generator.nextInt(MAX);
        }

        for(int i = 0; i < numbers.length ; i++){
            System.out.println(numbers[i]);
        }

        System.out.println("\n");

        MaxHeap testSorter = new MaxHeap();

        testSorter.heapsort(numbers);

        System.out.println("\n");
        for(int i = 0; i < numbers.length ; i++){
            System.out.println(numbers[i]);
        }

        for(int i = 0; i < numbers.length-1 ; i++){

            if (numbers[i] > numbers[i+1]) {
                fail("Not supposed to happen??");
            }

        }
        assert(true);

    }

    /*
    MaxHeap sortedArray = new MaxHeap(array);
    for(int lastIndex = sortedArray.nextPosition - 1; lastIndex > 0; lastIndex--){
      sortedArray.swap(0, lastIndex);
      sortedArray.reheapDown(0);
    }
    */

}