import org.junit.Assert;

public class HashCodeTest {
    @org.junit.Test
    public void testEquals_Symmetric() {
        DataReading x = new DataReading(14613461L, 34578930L, 48917186L, 58192769L, 4981906898L, 4917486761L);  // equals and hashCode check name field value
        DataReading y = new DataReading(14613461L, 34578930L, 48917186L, 58192769L, 4981906898L, 4917486761L);


        System.out.println(x.hashCode());
        System.out.println(y.hashCode());
        Assert.assertTrue(x.hashCode() == y.hashCode());

        System.out.println(x.hashCode());

    }

    @org.junit.Test
    public void testEquals_Student() {
        Student x = new Student("Daesang", "Yoon", 920725);  // equals and hashCode check name field value
        Student y = new Student("Daesang", "Yoon", 920725);


        System.out.println(x.hashCode());

        x.setFirstName("Gern");
        x.setLastName("Park");

        System.out.println(x.hashCode());

        System.out.println(y.hashCode());
        Assert.assertTrue(x.hashCode() == y.hashCode());
    }

    @org.junit.Test
    public void testEquals_Product() {
        ProductRecord x = new ProductRecord("Dota", 10.99, 10005, 11, 514, 2);  // equals and hashCode check name field value
        ProductRecord y = new ProductRecord("Dota", 10.99, 10005, 11, 514, 2);


        System.out.println(x.hashCode());
        System.out.println(y.hashCode());

        x.setPrice(11.99);
        System.out.println(x.hashCode());
        Assert.assertTrue(x.hashCode() == y.hashCode());
    }

    @org.junit.Test
    public void testEquals_Circle() {
        Circle x = new Circle(1, 1, 1 );  // equals and hashCode check name field value
        Circle y = new Circle(1, 1, 1 );


        System.out.println(x.hashCode());
        System.out.println(y.hashCode());
        Assert.assertTrue(x.hashCode() == y.hashCode());
    }
}