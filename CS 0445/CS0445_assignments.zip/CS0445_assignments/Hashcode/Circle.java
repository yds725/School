import java.awt.geom.Point2D;

public class Circle {

    private double x;
  private double y;
  private double radius;

  public Circle(double x, double y, double radius) {
    this.radius = radius;
    this.x = x;
    this.y = y;
  }

  public Point2D.Double getLocation() {
    return new Point2D.Double(x, y);
  }
  
  public double getRadius() {
    return radius;
  }

  public int hashCode() {
      int result;
      long value;
      value = Double.doubleToLongBits(x);
      result = (int) (value ^ (value >> 32));
      value = Double.doubleToLongBits(y);
      result = 31 * result + (int) (value ^ (value >> 32));
      value = Double.doubleToLongBits(radius);
      result = 31 * result + (int) (value ^ (value >> 32));
      return result;

  }

}