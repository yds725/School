public class Student {
  private String firstName;
  private String lastName;
  private int idNumber;

  public Student(String firstName, String lastName, int idNumber) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.idNumber = idNumber;
  }
  
  public String getFullName() {
    return firstName + " " + lastName;
  }
  
  public int getIdNumber() {
    return idNumber;
  }
  
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + idNumber;
    return result;
  }

  /*
  public int hashCode() {
    int first = firstName.hashCode();
    int last = lastName.hashCode();

    int result = first;
       result *= 31;
       result += last;
       result *= 31;
       result +=  idNumber;

       return result;

  }
  */

}