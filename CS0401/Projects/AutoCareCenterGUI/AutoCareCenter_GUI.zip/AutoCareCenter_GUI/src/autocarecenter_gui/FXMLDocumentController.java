/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autocarecenter_gui;

import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class FXMLDocumentController implements Initializable {
    public double costSum;
    
    final double BRAKES = 30.30;
    final double FLUID_CHK = 10.10;
    final double CAR_WASH = 5.05;
    final double EMMISION_INSPECTION = 40.40;
    final double TIRE_ROTATION = 20.20;
    final double REGULAR_TIRE = 250.25;
    final double SPORTS_TIRE = 350.35;
    final double REGULAR_OIL = 15.15;
    final double SYNTHETIC_OIL = 27.27;
    final double REGULAR_CUSTOMER_DISCOUNT = 0.15;
    final double NEW_CUSTOMER_DISCOUNT = 0.10;
   
    
    final double CHOICE_FOR_REGULAR = 0;
    final double CHOICE_FOR_DIFFERENT = 1;
    DecimalFormat df = new DecimalFormat("0.00");
    List<TextField> textFieldList = new ArrayList<TextField>();

    @FXML
    private RadioButton newCustomerRadioButton;

    @FXML
    private ToggleGroup customerType;

    @FXML
    private RadioButton regularCustomerRadioButton;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField phoneTextField;

    @FXML
    private TextField addressTextField;

    @FXML
    private TextField emailTextField;

    @FXML
    private Button printInvoiceButtion;

    @FXML
    private Label serviceCostLabel;

    @FXML
    private Button resetButton;

    @FXML
    private CheckBox brakesChkBox;

    @FXML
    private CheckBox tireRotationChkBox;

    @FXML
    private CheckBox fluidChkBox;

    @FXML
    private CheckBox carWashChkBox;

    @FXML
    private CheckBox inspectionChkBox;

    @FXML
    private CheckBox tireReplacementChkBox;

    @FXML
    private CheckBox oilChangeChkBox;
    
   
    @FXML
    private ChoiceBox tireReplacementChoiceBox;
   
    @FXML
    private ChoiceBox oilChangeChoiceBox;
   
     
  //  ObservableList<String> tireReplacementList = FXCollections.observableArrayList("Regular Tire", "Sports TIre");  
   
   
    private void getServiceCostLabel(){
        String cost = "Service Cost: " + "$" + df.format(costSum);
        serviceCostLabel.setText(cost);
    }
    
    @FXML
    void onChangeServiceCostRequest(ActionEvent event) {
        updateServiceCost();
        getServiceCostLabel();
        
    }
    
    private void updateServiceCost() {
        costSum = 0.0;
        updateBrakes();
        updateTireRotation();
        updateFluidCheck();
        updateCarWash();
        updateAnnualInspection();
        updateOilChangeCost();
        updateTireReplacementCost();
        updateCustomerDiscount();
        
    }
    private void updateBrakes(){
        if(brakesChkBox.isSelected()){
            costSum += BRAKES;
        }
    }
    
    private void updateTireRotation(){
         if(tireRotationChkBox.isSelected()){  
            costSum += TIRE_ROTATION;
         }
    }
    
    private void updateFluidCheck(){
         if(fluidChkBox.isSelected()){  
            costSum += FLUID_CHK;
         }
    }
    
    private void updateCarWash(){
        if(carWashChkBox.isSelected()){  
            costSum += CAR_WASH;
         }
    }
    
    private void updateAnnualInspection(){
        if(inspectionChkBox.isSelected()){  
            costSum += EMMISION_INSPECTION;
         }
    }
    
    private void updateOilChangeCost(){
        if(oilChangeChkBox.isSelected()){     
            oilChangeChoiceBox.setDisable(false);
            int number = oilChangeChoiceBox.getSelectionModel().selectedIndexProperty().getValue();
            if(number == CHOICE_FOR_REGULAR){
                 costSum += REGULAR_OIL;
             }else if(number == CHOICE_FOR_DIFFERENT){
                 costSum += SYNTHETIC_OIL;
             }  
        }else{
            oilChangeChoiceBox.setDisable(true);
        }
    }
    
    private void updateTireReplacementCost(){
        if(tireReplacementChkBox.isSelected()){
            tireReplacementChoiceBox.setDisable(false);
           int choice = tireReplacementChoiceBox.getSelectionModel().selectedIndexProperty().getValue();
           if(choice == CHOICE_FOR_REGULAR){
               costSum += REGULAR_TIRE;
           }else if(choice == CHOICE_FOR_DIFFERENT){
               costSum += SPORTS_TIRE;
           }
        }else{
            tireReplacementChoiceBox.setDisable(true);
        }
    }
    
    private void updateCustomerDiscount(){
        if(newCustomerRadioButton.isSelected()){
            costSum *= (1.0 - NEW_CUSTOMER_DISCOUNT);
        }else if(regularCustomerRadioButton.isSelected()){
            costSum *= (1.0 - REGULAR_CUSTOMER_DISCOUNT);
        }
    }
      
    @FXML
    void onPrintInvoice(ActionEvent event) throws Exception{
            /*JOptionPane.showMessageDialog(null, "Name: " + nameTextField.getText() +
            "\nPhone: " + phoneTextField.getText() +
            "\nE-Mail: " + emailTextField.getText() +
            "\nAddress: " + addressTextField.getText() +
            "\nTotal Invoice: " + "$ " + df.format(costSum)); */
          
             String format = "$" + df.format(costSum);
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("FXMLDocument2.fxml"));
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
            FXMLDocument2Controller invoiceController = (FXMLDocument2Controller)fxmlLoader.getController();
             invoiceController.getInvoice(nameTextField.getText(), phoneTextField.getText(),
                     emailTextField.getText(), addressTextField.getText(), format);
             
        } catch (IOException ex) {
           ex.printStackTrace();
        }
    }
    
    @FXML
    void onReset(ActionEvent event) {
         boolean state = false;
         brakesChkBox.setSelected(state);
         tireRotationChkBox.setSelected(state);
         fluidChkBox.setSelected(state);
         carWashChkBox.setSelected(state);
         inspectionChkBox.setSelected(state);
         tireReplacementChkBox.setSelected(state);
         oilChangeChkBox.setSelected(state);
         
         newCustomerRadioButton.setSelected(!state);
         
         textFieldList.add(nameTextField);
         textFieldList.add(phoneTextField);
         textFieldList.add(emailTextField);
         textFieldList.add(addressTextField);
         
         for(TextField textField : textFieldList){
             textField.setText("");
         }
        
         tireReplacementChoiceBox.setDisable(true);
         oilChangeChoiceBox.setDisable(true);
         
         costSum = 0;
         String cost = "Service Cost: " + "$" + df.format(costSum);
         serviceCostLabel.setText(cost);
         
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       tireReplacementChoiceBox.setItems(FXCollections.observableArrayList("Regular Tire", "Sports TIre"));
       oilChangeChoiceBox.setItems(FXCollections.observableArrayList("Regular Oil", "Synthetic Oil"));
       
       oilChangeChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
                public void changed(ObservableValue ov, Number value, Number selection){
                    
                    onChangeServiceCostRequest(null);
                    
                }
            });
       
       tireReplacementChoiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
                
                public void changed(ObservableValue ov, Number value, Number selection) {
                    
                    onChangeServiceCostRequest(null);
                }
                
            });
       
       tireReplacementChoiceBox.setDisable(true);
       oilChangeChoiceBox.setDisable(true);
       tireReplacementChoiceBox.setValue("Regular Tire");
       oilChangeChoiceBox.setValue("Regular Oil");
       
        String cost = "Service Cost: " + "$" + df.format(costSum);
        serviceCostLabel.setText(cost);// TODO
        
    }    
    
}    
        //costSum = 0;
        //onUpdateServiceCost for all check boxes and radio button and everything man except use that method inside listner class
        //onUpdateServiceCost(null)

     /*  private double calculateCost(){
        if(brakesChkBox.isSelected()){
            costSum += BRAKES; 
        } else{
            costSum -= BRAKES;
        }
        
        if(tireRotationChkBox.isSelected()){
            costSum += TIRE_ROTATION; 
        } else{
            costSum -= TIRE_ROTATION;
        }
        
        return costSum;
    } */

