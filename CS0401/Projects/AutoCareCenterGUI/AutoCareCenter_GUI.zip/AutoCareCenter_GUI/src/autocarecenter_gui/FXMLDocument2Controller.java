/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package autocarecenter_gui;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;



/**
 * FXML Controller class
 *
 * @author babyDae
 */
public class FXMLDocument2Controller implements Initializable {
    
    @FXML
    private Label labelName;
    
    @FXML
    private Label labelPhone;

    @FXML
    private Label labelEmail;

    @FXML
    private Label labelAddress;

    @FXML
    private Label labelServiceCost;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    
    }    
    
    public void getInvoice(String name, String phone, String email, String address, String cost){
        labelName.setText(name);
        labelPhone.setText(phone);
        labelEmail.setText(email);
        labelAddress.setText(address);
        labelServiceCost.setText(cost);
    }
    
}
