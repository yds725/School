#include <linux/unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>
#include <time.h>

/*semaphore data type encapsulation 
same as cs1550_sem
*/
struct car_sem
{
	int val;

	//some queue for process 
	struct car_process_queue* head;
	struct car_process_queue* tail;

};


void up(struct car_sem *sem) {
	syscall(__NR_sys_car_up, sem);
}

void down(struct car_sem *sem) {
	syscall(__NR_sys_car_down, sem);
}

//void initialize_sem() {
//
//}

typedef int bool;
#define true 1
#define false 0


int main(int argc, char* argv[]){
	
	srand(time(NULL)); //generating random seed
	int sizeOfBuffer = 10; //limit of car numbers in each road?
	

	//memory region for simulation start time
	void *mem_start_time = mmap(NULL, sizeof(time_t), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0); 
	//memory region for direction for flag police
	void *mem_direction = mmap(NULL, sizeof(char), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);
	void *mem_number_car = mmap(NULL, sizeof(long), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0); //memory region for number of cars
	void *mem_horn = mmap(NULL, sizeof(char), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0); //memory region for horn blown

	time_t* start_time = (time_t*)mem_start_time;
	char* flagpolice_direction = (char *)mem_direction;
	long* totalCarNumber = (long *)mem_number_car;
	char* blow_horn = (char *)mem_horn;

	void *memory_for_car_sem = mmap(NULL, sizeof(struct car_sem) * 6, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);
	void *memory_for_south = mmap(NULL, sizeof(int) * (sizeOfBuffer + 2), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);
	void *memory_for_north = mmap(NULL, sizeof(int) * (sizeOfBuffer + 2), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);

	//this is mutex, full, empty for bounded-buffer problem
	struct car_sem* mutex_lock = (struct car_sem*)memory_for_car_sem;
	struct car_sem* north_full = (struct car_sem*)memory_for_car_sem + 1;
	struct car_sem* north_empty = (struct car_sem*)memory_for_car_sem + 2;
	struct car_sem* south_full = (struct car_sem*)memory_for_car_sem + 3;
	struct car_sem* south_empty = (struct car_sem*)memory_for_car_sem +4;
	//number of cars at intersection
	struct car_sem* car_intersection = (struct car_sem*)memory_for_car_sem + 5;

	//initialize sempahore struct values
	mutex_lock->val = 1;
	north_full->val= 0;
	south_full->val = 0;
	north_empty->val = sizeOfBuffer;
	south_empty->val = sizeOfBuffer;
	car_intersection->val = 0;

	//initialize all nodes
	mutex_lock->head = NULL;
	north_full->head = NULL;
	south_full->head = NULL;
	north_empty->head = NULL;
	south_empty->head = NULL;
	car_intersection->head = NULL;

	mutex_lock->tail = NULL;
	north_full->tail = NULL;
	south_full->tail = NULL;
	north_empty->tail = NULL;
	south_empty->tail = NULL;
	car_intersection->tail = NULL;

	//initialze some variables that are shared in memory according lecture slides
	*totalCarNumber = 0;
	*flagpolice_direction = ' ';
	*blow_horn = 'F';

	//No cars arrived so flagpolice is sleeping
	printf("The flagperson is now asleep\n");
	
	//reference to producer, consumer, buffer for north side
	int* north_producer_ref = (int*)memory_for_north;
	int* north_consumer_ref = (int*)memory_for_north+1;
	int* north_buffer_ref = (int*)memory_for_north+2;

	int* south_producer_ref = (int*)memory_for_south;
	int* south_consumer_ref = (int*)memory_for_south+1;
	int* south_buffer_ref = (int*)memory_for_south + 2;

	//initialize producer, consumer, buffer ref to 0

	*north_producer_ref = 0;
	*north_consumer_ref = 0;
	*south_producer_ref = 0;
	*south_consumer_ref = 0;

	//initialize buffer to 0
	int i;

	for (i = 0; i < sizeOfBuffer; i++) {
		north_buffer_ref[i] = 0;
		south_buffer_ref[i] = 0;
	}

	//Start time
	*start_time = time(NULL);

	//start making process
	//int cur_process = fork();

	if (fork() == 0) {

		//North side producer proces
		if (fork() == 0) {
			while (true) {

				down(north_empty);
				down(mutex_lock);

				*totalCarNumber = *totalCarNumber + 1;
				
				north_buffer_ref[*north_producer_ref % sizeOfBuffer] = *totalCarNumber;

				*north_producer_ref = *north_producer_ref+ 1;

				if (car_intersection->val <= 0 && *blow_horn == 'F') {

					//blow car horn
					*blow_horn = 'T';
					*flagpolice_direction = 'N';
					printf("The flagperson is now awake\n");
					printf("Car %d coming from the %c direction, blew their horn at time %d.\n", *totalCarNumber, 'N', time(NULL) - *start_time);
				}
				//arrive in queue or other side of road
				//everything in order according to lecture slide
				printf("Car %d coming from the %c direction arrived in the queue at time %d.\n", *totalCarNumber, 'N', time(NULL) - *start_time);
				up(mutex_lock);
				up(north_full);
				up(car_intersection);

				//if car is not following there may be delay or sleep for 20 secs before new car comes
				if (rand() % 10 >= 8) {
					sleep(20);
				}

			}
		}
		//South side process starts
		else {
			while (true) {

				down(south_empty);
				down(mutex_lock);

				*totalCarNumber = *totalCarNumber + 1;

				south_buffer_ref[*south_producer_ref % sizeOfBuffer] = *totalCarNumber;
				*south_producer_ref = *south_producer_ref + 1;

				if (car_intersection->val <= 0 && *blow_horn == 'F') {
					//blow horn at south
					*blow_horn = 'T';
					*flagpolice_direction = 'S';
					printf("The flagperson is now awake\n");
					printf("Car %d coming from the %c direction, blew their horn at time %d.\n", *totalCarNumber, 'S', time(NULL) - *start_time);
				}
				//Arrive at other side from South
				printf("Car %d coming from the %c direction arrived in the queue at time %d.\n", *totalCarNumber, 'S', time(NULL) - *start_time);
				up(mutex_lock);
				up(south_full);
				up(car_intersection);

				//if car is not following there may be delay or sleep for 20 secs before new car comes
				if (rand() % 10 >= 8) {
					sleep(20);
				}
			}
		}
	}

	//Consumer process
	if (fork() == 0) {
		while (true) {
			int numberOfCar;
			char directionOfCar;

			down(mutex_lock);

			if (car_intersection->val == 0) {
				printf("The flagperson is now asleep\n");
				*blow_horn = 'F';
			}
			up(mutex_lock);

			down(car_intersection);
			down(mutex_lock);

			if (car_intersection->val < 0) {
				printf("Should not run consumer process without a car in queue\n");
				exit(1);
			}

			if (*flagpolice_direction == 'N' && south_full->val >= 10) {
				*flagpolice_direction = 'S';
			}
			else if (*flagpolice_direction == 'S' && north_full->val >= 10) {
				*flagpolice_direction = 'N';
			}

			if (*flagpolice_direction == 'N') {
				down(north_full);
				numberOfCar = north_buffer_ref[(*north_consumer_ref) % sizeOfBuffer];
				directionOfCar = 'N';
				*north_consumer_ref = *north_consumer_ref + 1;

				if (north_full->val == 0) {
					*flagpolice_direction = 'S';
				}

			}
			else if (*flagpolice_direction == 'S') {
				down(south_full);
				numberOfCar = south_buffer_ref[(*south_consumer_ref) % sizeOfBuffer];
				directionOfCar = 'S';
				*south_consumer_ref = *south_consumer_ref + 1;

				if (south_full->val == 0)
					*flagpolice_direction = 'N';
			}
			up(mutex_lock);
			sleep(2); // each car takes 2 seconds to go through area

			printf("Car %d coming from the %c direction left the construction zone at time %d.\n", numberOfCar, directionOfCar, time(NULL) - *start_time);
			if (directionOfCar == 'N') {
				up(north_empty);
			}
			if (directionOfCar == 'S') {
				up(south_empty);
			}
		}//end of while loop
	}//end of consumer

	int waiting;
	wait(&waiting);
	return 0;

 }//end of main