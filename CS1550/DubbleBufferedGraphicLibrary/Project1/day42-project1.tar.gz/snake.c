/*CS1550-Project 1 Snake game
	Daesang Yoon / day42@pitt.edu
	Test driver for library.c file
*/

#include "graphics.h"
#include <stdio.h>
#define true 1
#define false 0

struct coordinate {
	int x1;
	int x2;
	int x3;
	int x4;
	int y1;
	int y2;
	int y3;
	int y4;
};

int main() {
	const color_t pixelColor_green = RGB(31, 59, 1); //bright green color
	const color_t pixelColor_black = RGB(0, 0, 0); //black color to erase trail behind
	struct coordinate currentPos = { .x1 = 320,.y1 = 320,
									 .x2 = 320, .y2 = 319,
									  .x3 = 321, .y3 = 320,
									   .x4 = 321, .y4 = 319	 }; //setting start pixel coordinate

	char input1;
	char input2;

	int i;

	//initialize framebuffer 
	init_graphics();

	printf("\nSnake Test Program for graphic library functions\n");
	printf("Controls: [w,a,s,d] Quit: [q] Press any key to continue\n" );
	input1 = getc(stdin); // scanf 

	//create new offscreenbuffer
	void *img_offscreen_buffer = new_offscreen_buffer();

	if (input1 == 'q') {
		return 0;
	} else {
		while (true) {

			draw_pixel(img_offscreen_buffer, currentPos.x1, currentPos.y1, pixelColor_green);
			draw_pixel(img_offscreen_buffer, currentPos.x2, currentPos.y2, pixelColor_green);
			draw_pixel(img_offscreen_buffer, currentPos.x3, currentPos.y3, pixelColor_green);
			draw_pixel(img_offscreen_buffer, currentPos.x4, currentPos.y4, pixelColor_green);
			blit(img_offscreen_buffer);

				//input2 = getkey();
				if (input2 == 'w') {
					
						currentPos.y1--;
						currentPos.y2--;
						currentPos.y3--;
						currentPos.y4--;
						currentPos.y1 = (currentPos.y1 + 480) % 480;
						currentPos.y2 = (currentPos.y2 + 480) % 480;
						currentPos.y3 = (currentPos.y3 + 480) % 480;
						currentPos.y4 = (currentPos.y4 + 480) % 480;

						draw_pixel(img_offscreen_buffer, currentPos.x1, (currentPos.y1 + 1) % 480, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x2, (currentPos.y2 + 1) % 480, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x3, (currentPos.y3 + 1) % 480, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x4, (currentPos.y4 + 1) % 480, pixelColor_black);						
						
					
					/*
					for (i = 0; i < 8; i++) {
						currentPos.y = currentPos.y - 1;
						draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
					}
					*/
				}
				else if (input2 == 'a') {
					
						currentPos.x1--;
						currentPos.x2--;
						currentPos.x3--;
						currentPos.x4--;
						currentPos.x1 = (currentPos.x1 + 640) % 640;
						currentPos.x2 = (currentPos.x2 + 640) % 640;
						currentPos.x3 = (currentPos.x3 + 640) % 640;
						currentPos.x4 = (currentPos.x4 + 640) % 640;

						//clear_screen(img_offscreen_buffer);
						//draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
						
						draw_pixel(img_offscreen_buffer, (currentPos.x1 + 1) % 640, currentPos.y1, pixelColor_black);
						draw_pixel(img_offscreen_buffer, (currentPos.x2 + 1) % 640, currentPos.y2, pixelColor_black);
						draw_pixel(img_offscreen_buffer, (currentPos.x3 + 1) % 640, currentPos.y3, pixelColor_black);
						draw_pixel(img_offscreen_buffer, (currentPos.x4 + 1) % 640, currentPos.y4, pixelColor_black);
						
						//blit(img_offscreen_buffer);
	
					/*
					for (i = 0; i < 8; i++) {
						currentPos.x = currentPos.x - 1;
						draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
					}
					*/
				}
				else if (input2 == 's') {
					
						currentPos.y1++;
						currentPos.y2++;
						currentPos.y3++;
						currentPos.y4++;

						currentPos.y1 = currentPos.y1 % 480;
						currentPos.y2 = currentPos.y2 % 480;
						currentPos.y3 = currentPos.y3 % 480;
						currentPos.y4 = currentPos.y4 % 480;

						//clear_screen(img_offscreen_buffer);
						//draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
						
						draw_pixel(img_offscreen_buffer, currentPos.x1, currentPos.y1 - 1, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x2, currentPos.y2 - 1, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x3, currentPos.y3 - 1, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x4, currentPos.y4 - 1, pixelColor_black);
						

						//blit(img_offscreen_buffer);
					/*for (i = 0; i < 8; i++) {
						currentPos.y = currentPos.y + 1;
						draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
					}*/
				}
				else if (input2 == 'd') {
						currentPos.x1++;
						currentPos.x2++;
						currentPos.x3++;
						currentPos.x4++;
						currentPos.x1 = currentPos.x1 % 640;
						currentPos.x2 = currentPos.x2 % 640;
						currentPos.x3 = currentPos.x3 % 640;
						currentPos.x4 = currentPos.x4 % 640;

						//clear_screen(img_offscreen_buffer);
						//draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
						
						draw_pixel(img_offscreen_buffer, currentPos.x1 - 1, currentPos.y1, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x2 - 1, currentPos.y2, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x3 - 1, currentPos.y3, pixelColor_black);
						draw_pixel(img_offscreen_buffer, currentPos.x4 - 1, currentPos.y4, pixelColor_black);
						
						//blit(img_offscreen_buffer);
				
					/*for (i = 0; i < 8; i++) {
						currentPos.x = currentPos.x + 1;
						draw_pixel(img_offscreen_buffer, currentPos.x, currentPos.y, pixelColor_green);
					}*/
				}
				else if (input2 == 'q') {
					clear_screen(img_offscreen_buffer);
					blit(img_offscreen_buffer);
					break;
				}

			sleep_ms(2);

			input2 = getkey();
			//blit(img_offscreen_buffer);
		}

		exit_graphics();
		return 0;
	} //end of first else
	
}