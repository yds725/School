/*Daesang
*CS1550 Project 1 - Double Buffered Graphics Library
 library function file that set pixel to particular color, draw basic shapes, read keypresses
*/

#include "graphics.h"

#define SCREEN_CLEAR_CODE "\0333[2J"

#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <termios.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <linux/fb.h>
#include <sys/stat.h>


typedef enum {false, true} boolean; //make boolean type alias bc c has no boolean keyword

static int framebuffer; //stores framebuffer descriptor id
static void* fb_address; //address returned from mmap() call
static int fb_size_screen; //size of screen stored in framebuffer
static int line_length;
static int virtual_res;
static boolean initialized = false;

void screen_clear();

/*stdin = 0 (STDIN_FILENO), stdout = 1 (STDOUT_FILENO)
*/

/*initialize graphics*/
void init_graphics() {
	
	struct fb_var_screeninfo vscreeninfo; //FBIOGET_VSCREENINFO gives virtual resolution
	struct fb_fix_screeninfo fscreeninfo; //FBIOGET_FSCREENINFO determines bit depth
	struct termios terminal_setting; //describes current terminal settings:related to TCGETS & TCSETS command ioctl() sys call
	

	framebuffer = open("/dev/fb0", O_RDWR);

	//if file descriptor id is -1, it failed to open file
	if (framebuffer == -1) {
		return;
	}

	if (ioctl(framebuffer, FBIOGET_VSCREENINFO, &vscreeninfo) == -1) {
		return;
	}

	if (ioctl(framebuffer, FBIOGET_FSCREENINFO, &fscreeninfo) == -1) {
		return;
	}

	virtual_res = vscreeninfo.yres_virtual;
	line_length = fscreeninfo.line_length / 2;
	fb_size_screen = virtual_res * line_length * 2; //total size of mmap()ed file is yres_virtual * line_length

	//this maps file into address space so that we can use it as array and use loads stores to manipulate file contents
	fb_address = mmap(NULL, fb_size_screen, PROT_READ | PROT_WRITE, MAP_SHARED, framebuffer, 0); //idea of memory mapping

	screen_clear(); //clear screen

	ioctl(STDIN_FILENO, TCGETS, &terminal_setting); //this will get terminal settings of current file
	terminal_setting.c_lflag &= ~ICANON; //disabling canonical mode by forcing ICANON bit to zero
	terminal_setting.c_lflag &= ~ECHO; //disable echo mode by forcing bit to zero

	ioctl(STDIN_FILENO, TCSETS, &terminal_setting); //now disabled canonical mode and echo mode will be stored in terminal setting

	initialized = true; //flag to check if grpahic is initialized
}

void exit_graphics() {
	struct termios terminal_setting;

	if (initialized == false) {
		return;
	}

	munmap(fb_address, fb_size_screen); //unmapping mmap
	close(framebuffer); //closing framebuffer fid; deallocating fid
	ioctl(STDIN_FILENO, TCGETS, &terminal_setting); //trying to reenable echo and canonical mode
	terminal_setting.c_lflag |= ICANON;
	terminal_setting.c_lflag |= ECHO;
	ioctl(STDIN_FILENO, TCSETS, &terminal_setting);

	initialized = false; //status of graphic initialization to false

}

void screen_clear() {
	write(STDOUT_FILENO, SCREEN_CLEAR_CODE, 4); //tells to terminal to clear screen by printing out to standard output using ANSI escape code
}

char getkey() {
	fd_set readfds; //this is filedecsriptor sets for select function (bit array); manages which file descriptor to be used

	//initialize readfds set
	FD_ZERO(&readfds); //clear the set to make empty set
	FD_SET(STDIN_FILENO, &readfds); //adds file descriptor to set

	struct timeval wait_time; //if timeval is 0 select blocks call infinitely so we have to set wait time
	wait_time.tv_sec = 0;
	wait_time.tv_usec = 0;


	char input; //user input buffer

	if ((select(STDIN_FILENO + 1, &readfds, NULL, NULL, &wait_time)) > 0 ){ //so select function waits until user types input then it returns number of file descriptors
		read(STDIN_FILENO, &input, 1); //read user input by 1 byte
	}

	return input;
}

void sleep_ms(long ms) {
	/* timespec{ time_t tv_sec; /seconds
				 long	tv_nsec; /nanoseconds }
	*/
	struct timespec sleeptime = {ms / 1000, (ms % 1000) * 1000000 }; //sleeptime just multiply by 1,000,000
	nanosleep(&sleeptime, NULL);

}

void clear_screen(void *img) {
	int i;
	for (i = 0; i < fb_size_screen; i++) {
		*(((char *)img) + i) = 0;
	}
}

/*draw pixel at (x,y) coordinate to specific color*/
void draw_pixel(void *img, int x, int y, color_t color) {
	if (!initialized) {
		return;
	}

	//if x y coordinate at offscreen or out of boundary, do not draw
	if (x < 0 || y < 0 || x >= line_length || y >= virtual_res) {
		return;
	}

	int offset = (y * line_length) + x; //set offset and later modify it by pointer arithmetic

	*((color_t*)(img) + offset) = color; //this color come from RGB macro

	/* 
	color_t* pixel = img + offset; //Find certian location of framebuffer address using x,y coordinate
	*pixel = color; //set 
	*/
}

/*Bresenham's Drawing Line Algorithm 
source: https://rosettacode.org/wiki/Bitmap/Bresenham%27s_line_algorithm#C
Idea of implementaion from GeekForGeek
Draw line between coordinate (x1,y1) to (x2,y2)
*/
void draw_line(void *img, int x1, int y1, int x2, int y2, color_t c) {
	if (!initialized) {
		return;
	}

	int dx = absoluteVal(x2 - x1);
	int sx = x1 < x2 ? 1 : -1;
	int dy = absoluteVal(y2 - y1);
	int sy = y1 < y2 ? 1 : -1;

	int error = (dx > dy ? dx : -dy) / 2;
	int err2;

	for (;;) {
		draw_pixel(img, x1, y1, c);
		if (x1 == x2 && y1 == y2) {
			break;
		}
		err2 = error;

		if (err2 > -dx) {
			error -= dy; 
			x1 += sx;
		}

		if (err2 < dy) {
			error += dx;
			y1 += sy;
		}
	}

}

//computing absolute value of number
int absoluteVal(int n) {
	int result = n < 0 ? -n : n;
	return result;
}

void* new_offscreen_buffer() {
	if (!initialized) {
		return NULL;
	}
	//this is concept of double buffering to make duplicate array of pixels in RAM 
	void* offscreen_address;
	
	//create new buffer using memory mapping which returns another address of new offscreen buffer
	offscreen_address = mmap(NULL, fb_size_screen, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

	return offscreen_address;
}

/*bit block transfer function to memory copy from offscreen buffer to framebuffer*/
//Different
void blit(void *src) {
	if (!initialized) {
		return;
	}

	//type cast addresses to char* (char takes 1 byte) 
	char* csrc = (char*)src;
	char* cdest = (char*)fb_address;

	//for loop to copy every byte from source off_buffer to framebuffer
	int i;
	for (i = 0; i < fb_size_screen; i++) {
		cdest[i] = csrc[i];
	}
}

