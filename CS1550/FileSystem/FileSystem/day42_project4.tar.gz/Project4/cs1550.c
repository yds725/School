/*
	FUSE: Filesystem in Userspace
	Copyright (C) 2001-2007  Miklos Szeredi <miklos@szeredi.hu>

	This program can be distributed under the terms of the GNU GPL.
	See the file COPYING.
*/

#define	FUSE_USE_VERSION 26

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>


//size of a disk block
#define	BLOCK_SIZE 512

//we'll use 8.3 filenames
#define	MAX_FILENAME 8
#define	MAX_EXTENSION 3

#define SIZE_OF_DISK 5242880 // 5MB in bytes using calculator
//count of blocks that fit into disk minus tracking bitmap
#define NUMBER_OF_BLOCKS (SIZE_OF_DISK / BLOCK_SIZE - ((SIZE_OF_DISK - 1) / (8 * BLOCK_SIZE * BLOCK_SIZE) + 1))


//How many files can there be in one directory?
#define MAX_FILES_IN_DIR (BLOCK_SIZE - sizeof(int)) / ((MAX_FILENAME + 1) + (MAX_EXTENSION + 1) + sizeof(size_t) + sizeof(long))

static const char *DISK_PATH_NAME = ".disk"; //disk path name
static long block_allocated = 0; // last allocated block

//The attribute packed means to not align these things
struct cs1550_directory_entry
{
	int nFiles;	//How many files are in this directory.
				//Needs to be less than MAX_FILES_IN_DIR

	struct cs1550_file_directory
	{
		char fname[MAX_FILENAME + 1];	//filename (plus space for nul)
		char fext[MAX_EXTENSION + 1];	//extension (plus space for nul)
		size_t fsize;					//file size
		long nStartBlock;				//where the first block is on disk
	} __attribute__((packed)) files[MAX_FILES_IN_DIR];	//There is an array of these

	//This is some space to get this to be exactly the size of the disk block.
	//Don't use it for anything.  
	char padding[BLOCK_SIZE - MAX_FILES_IN_DIR * sizeof(struct cs1550_file_directory) - sizeof(int)];
} ;

typedef struct cs1550_root_directory cs1550_root_directory;

#define MAX_DIRS_IN_ROOT (BLOCK_SIZE - sizeof(int)) / ((MAX_FILENAME + 1) + sizeof(long))

struct cs1550_root_directory
{
	int nDirectories;	//How many subdirectories are in the root
						//Needs to be less than MAX_DIRS_IN_ROOT
	struct cs1550_directory
	{
		char dname[MAX_FILENAME + 1];	//directory name (plus space for nul)
		long nStartBlock;				//where the directory block is on disk
	} __attribute__((packed)) directories[MAX_DIRS_IN_ROOT];	//There is an array of these

	//This is some space to get this to be exactly the size of the disk block.
	//Don't use it for anything.  
	char padding[BLOCK_SIZE - MAX_DIRS_IN_ROOT * sizeof(struct cs1550_directory) - sizeof(int)];
} ;


typedef struct cs1550_directory_entry cs1550_directory_entry;

//How much data can one block hold?
#define	MAX_DATA_IN_BLOCK (BLOCK_SIZE - sizeof(long))

struct cs1550_disk_block
{	
	long nextBlock;
	//All of the space in the block can be used for actual data
	//storage.
	char data[MAX_DATA_IN_BLOCK];
};

typedef struct cs1550_disk_block cs1550_disk_block;

static FILE* open_disk(void) {
	FILE *file = fopen(DISK_PATH_NAME, "r+b");
	if (!file) { //if file is not null
		printf("Disk file may not exist or cannot be opened\n");
		return NULL;
	}

	if (fseek(file, 0, SEEK_END) || ftell(file) != SIZE_OF_DISK) {
		fclose(file);
		printf("Disk file size is not valid. Error!\n");
		return NULL;
	}
	
	return file;

}

static void close_disk(FILE* file) {
	if (fclose(file)) {
		printf("Cannot close file\n");
	}
}

//return index of free block available in disk file
static long get_next_free_block(FILE* file) {
	long i;
	long current = -1;
	char current_byte;

	for (i = 0; i < NUMBER_OF_BLOCKS; i++) {
		block_allocated = (block_allocated + 1) % NUMBER_OF_BLOCKS;

		if (!block_allocated)
			continue;

		long this_byte = SIZE_OF_DISK - (block_allocated / 8) - 1;
		if (this_byte != current) {
			if (fseek(file, this_byte, SEEK_SET) || fread(&current_byte, 1, 1, file) != 1)
				return -4; // error
			current = this_byte;
		}
		
		int bit = block_allocated % 8;
		char shifted = 1 << bit;
		if (!(current_byte & shifted)) {
			return block_allocated; //free block
		}
	}
	return -1; //if blocks not free
}

//number as prompt for free blocks and get free blocks' index
static long* prompt_free_block(FILE* file, size_t number) {
	long *index_of_blocks = malloc(sizeof(long) * number);
	*index_of_blocks = 0;

	long temp_block = block_allocated;
	int i;

	for (i = 0; i < number; i++) {
		long index = get_next_free_block(file);
		if (index < 0 || index == *index_of_blocks) {
			free(index_of_blocks);
			block_allocated = temp_block;
			return NULL; //all blocks are used
		}
		*(index_of_blocks + i) = index;
	}
	return index_of_blocks;
}

//make bit in bitmap. 
static int create_bitmap(FILE *file, long index_block, char value) {

	if (index_block >= NUMBER_OF_BLOCKS) {
		printf("Block does not exists. Error!");
		return -1; //error
	}

	long this_byte = SIZE_OF_DISK - (index_block / 8) - 1;
	char byte;
	int bit = index_block % 8;
	if (fseek(file, this_byte, SEEK_SET) || fread(&byte, 1, 1, file) != 1) 
		return -1; //error

	char shifted = 1 << bit;
	if (value) {
		byte |= shifted;
	}
	else {
		byte &= (~shifted);
	}
	if (fseek(file, this_byte, SEEK_SET) || fwrite(&byte, 1, 1, file) != 1) 
		return -1; //error

	return 0; //block is free
}


static void* load_block_disk(FILE *file, long index_block) {

	if (index_block >= NUMBER_OF_BLOCKS) {
		printf("Block at that index does not exists\n");
		return NULL;
	}

	if (fseek(file, index_block * BLOCK_SIZE, SEEK_SET)) {
		//printf"failed to seek to block %ld\n");
		return NULL;
	}

	void *block = malloc(BLOCK_SIZE);
	if (fread(block, BLOCK_SIZE, 1, file) != 1) {
		printf("Cannot load block!");
		free(block);
		return NULL;
	}
	return block;
}

//store block in certain index of block of disk file 
static int keep_block_disk(FILE *file, long index_block, void *block) {
	if (index_block >= NUMBER_OF_BLOCKS) {
		printf("Requested block does not exist\n");
		return -1; //error
	}
	if (fseek(file, index_block * BLOCK_SIZE, SEEK_SET)) {
	
		return -1; //error
	}
	if (fwrite(block, BLOCK_SIZE, 1, file) != 1) {
		printf("Cannot write to block \n");
		return -1; //erro
	}
	return 0; //if success return 0
}

static cs1550_root_directory* load_root_dir(FILE *file) {
	return (cs1550_root_directory*)load_block_disk(file, 0); //load or get root direct block from disk file
}

static cs1550_directory_entry* load_sub_dir(FILE *file, long index_block) {
	return (cs1550_directory_entry*)load_block_disk(file, index_block); //load subdir disk at index of block of index in idsk file
}

static cs1550_disk_block* load_file_block(FILE *file, long index_block) {
	return (cs1550_disk_block*)load_block_disk(file, index_block); //load file block at block of index in disk file
}


/*
 * Called whenever the system wants to know the file attributes, including
 * simply whether the file exists or not. 
 *
 * man -s 2 stat will show the fields of a stat structure
 */
static int cs1550_getattr(const char *path, struct stat *stbuf)
{
	int res = 0;

	memset(stbuf, 0, sizeof(struct stat));

	//is path the root dir?
	if (strcmp(path, "/") == 0) {
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2;
	}
	else {
		char dir[MAX_FILENAME + 1];
		char filename[MAX_FILENAME + 1];
		char extension[MAX_EXTENSION + 1];
		int total_path = sscanf(path, "/%[^/]/%[^.].%s", dir, filename, extension);

		if (total_path < 1) 
			return -ENOENT;

		FILE *disk_file = open_disk(); //try to open disk file
		if (!disk_file) return -ENXIO;
		
		cs1550_root_directory* root_node = load_root_dir(disk_file); //load root directory block
		if (!root_node) {
			res = -EIO;
		} else {
			
			size_t index_dir;
			//check whether same dir name exists
			for (index_dir = 0; index_dir < root_node->nDirectories; index_dir ++) {
				if (strcmp(root_node->directories[index_dir].dname, dir) == 0) {
					break;
				}
			}
			if (index_dir == root_node->nDirectories) {
				res = -ENOENT;
			}
			else {
				if (total_path == 1) {
					stbuf->st_mode = S_IFDIR | 0755;
					stbuf->st_nlink = 2;
					res = 0; //no error
				}
				else {
					
					cs1550_directory_entry* sub_dir = load_sub_dir(disk_file, root_node->directories[index_dir].nStartBlock); //load sub dir
					if (!sub_dir) {
						res = -EIO;
					}
					else {
						
						res = -ENOENT;
						size_t index_file;
						//check whether same filename or extension exists
						for (index_file = 0; index_file < sub_dir->nFiles; index_file++) {
							if (strcmp(sub_dir->files[index_file].fname, filename) == 0 && strcmp(sub_dir->files[index_file].fext, extension) == 0) 
							{
								stbuf->st_mode = S_IFREG | 0666;
								stbuf->st_nlink = 1; 
								stbuf->st_size = sub_dir->files[index_file].fsize; //file size
								res = 0; // no error
								break;
							}
						}
						free(sub_dir);
					}
				}
			}
			free(root_node);
		}
		
		close_disk(disk_file); //close disk file
	}
	return res;
}

/* 
 * Called whenever the contents of a directory are desired. Could be from an 'ls'
 * or could even be when a user hits TAB to do autocompletion
 */
static int cs1550_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
	off_t offset, struct fuse_file_info *fi)
{
	//Since we're building with -Wall (all warnings reported) we need
	//to "use" every parameter, so let's just cast them to void to
	//satisfy the compiler
	(void)offset;
	(void)fi;

	char dir[MAX_FILENAME + 1]; 
	char filename[MAX_FILENAME + 1];
	char extension[MAX_EXTENSION + 1];
	int total_path = sscanf(path, "/%[^/]/%[^.].%s", dir, filename, extension);

	if (total_path > 1) 
		return -ENOENT;

	//the filler function allows us to add entries to the listing
	//read the fuse.h file for a description (in the ../include dir)
	filler(buf, ".", NULL, 0);
	filler(buf, "..", NULL, 0);
	
	FILE *disk_file = open_disk(); //open disk

	if (!disk_file) 
		return -ENXIO;
	
	int res = -ENOENT; // -ENOENT
	
	cs1550_root_directory* root_dir = load_root_dir(disk_file); //load root dir

	if (!root_dir) {
		res = -EIO;
	} else {
		size_t index_dir;
		if (!strcmp(path, "/")) {
			
			for (index_dir = 0; index_dir < root_dir->nDirectories; index_dir++) {
				filler(buf, root_dir->directories[index_dir].dname, NULL, 0);
			}
			res = 0;
		}
		else if (total_path == 1) {
			
			size_t index_dir;
			//search for same sub dir name
			for (index_dir = 0; index_dir < root_dir->nDirectories; index_dir++) {
				if (strcmp(root_dir->directories[index_dir].dname, dir) == 0) {
					break;
				}
			}
		
			if (index_dir < root_dir->nDirectories) {
				// load sub dir block
				cs1550_directory_entry* sub_dir = load_sub_dir(disk_file, root_dir->directories[index_dir].nStartBlock);
				if (!sub_dir) {
					res = -EIO;
				} else {
				
					size_t index_file;
					for (index_file = 0; index_file < sub_dir->nFiles; index_file++) {
						
						char filename[MAX_FILENAME + MAX_EXTENSION + 1];
						strcpy(filename, sub_dir->files[index_file].fname);//copy filename
						strcat(filename, ".");
						strcat(filename, sub_dir->files[index_file].fext); //copy extension
						filler(buf, filename, NULL, 0); //fill filename??
					}
					res = 0;
					free(sub_dir);
				}
			}
		}
		free(root_dir);
	}
	
	close_disk(disk_file); //close file
	return res;
}

/* 
 * Creates a directory. We can ignore mode since we're not dealing with
 * permissions, as long as getattr returns appropriate ones for us.
 */
static int cs1550_mkdir(const char *path, mode_t mode) {
	(void)mode;
	//(void) path;
	char dir[MAX_FILENAME + 1]; 
	char filename[MAX_FILENAME + 1];
	char extension[MAX_EXTENSION + 1];

	int total_path = sscanf(path, "/%[^/]/%[^.].%s", dir, filename, extension);

	if (total_path > 1) 
		return -EPERM;

	// Check if directory name is too long
	if (strlen(dir) > MAX_FILENAME) 
		return -ENAMETOOLONG;

	FILE *disk_file = open_disk();

	if (!disk_file) 
		return -ENXIO;

	int res = 0;

	cs1550_root_directory* root_dir = load_root_dir(disk_file); //try to load root dir

	if (!root_dir) {
		res = -ENXIO;
	} else {
		
		size_t index_dir;
		//search for same sub dir name
		for (index_dir = 0; index_dir < root_dir->nDirectories; index_dir++) {
			if (strcmp(root_dir->directories[index_dir].dname, dir) == 0) {
				res = -EEXIST; //directory already exists
				break;
			}
		}
		// if directoy is too full
		if (!res && root_dir->nDirectories == MAX_DIRS_IN_ROOT) { //!-1 -> 0 
			res = -ENOSPC; //no space
		}
		
		if (!res) {
			//make new sub dir if not existed 
			long new_index_block = get_next_free_block(disk_file); 
			if (new_index_block > 0) {
				strcpy(root_dir->directories[root_dir->nDirectories].dname, dir);
				root_dir->directories[root_dir->nDirectories].nStartBlock = new_index_block;
				root_dir->nDirectories++;
				if (keep_block_disk(disk_file, 0, root_dir) || create_bitmap(disk_file, new_index_block, 1)) {
					res = -EIO;
				}
			}
			else if (new_index_block == -1) {
				res = -ENOSPC;
			}
			else {
				res = -EIO;
			}
		}
		free(root_dir);
	}
	close_disk(disk_file);
	return res;
}

/* 
 * Removes a directory.
 */
static int cs1550_rmdir(const char *path)
{
	(void) path;
    return 0;
}

/* 
 * Does the actual creation of a file. Mode and dev can be ignored.
 *
 */
static int cs1550_mknod(const char *path, mode_t mode, dev_t dev)
{
	(void)mode;
	(void)dev;
	
	char dir[MAX_FILENAME + 1]; 
	char filename[MAX_FILENAME + 1];
	char extension[MAX_EXTENSION + 1];

	int total_path = sscanf(path, "/%[^/]/%[^.].%s", dir, filename, extension);

	if (total_path < 3) 
		return -EPERM;

	// Check whether directory name is too long
	if (strlen(dir) > MAX_FILENAME) 
		return -ENOENT;

	// Check whether file name or extension is too long
	if (strlen(filename) > MAX_FILENAME || strlen(extension) > MAX_EXTENSION) 
		return -ENAMETOOLONG;

	FILE *disk_file = open_disk();
	if (!disk_file) 
		return -ENXIO;

	int res = -ENOENT;
	
	cs1550_root_directory* root_dir = load_root_dir(disk_file);

	if (!root_dir) {
		res = -EIO;
	}
	else {
		// Search for subdirectory
		size_t index_dir;
		for (index_dir = 0; index_dir < root_dir->nDirectories; index_dir++) {
			if (strcmp(root_dir->directories[index_dir].dname, dir) == 0) {
				res = 0;
				break;
			}
		}
		// Subdirectory exists
		if (!res) {
			// Load subdirectory
			long index_sub_dir_block = root_dir->directories[index_dir].nStartBlock;
			cs1550_directory_entry* sub_dir = load_sub_dir(disk_file, index_sub_dir_block);

			if (!sub_dir) {
				res = -EIO;
			} else {
				// Search for file
				size_t index_file;
				for (index_file = 0; index_file < sub_dir->nFiles; index_file++) {
					if (strcmp(sub_dir->files[index_file].fname, filename) == 0 && strcmp(sub_dir->files[index_file].fext, extension) == 0) {
						res = -EEXIST; //file name laready exists
						break;
					}
				}
				// if directory is too full
				if (!res && sub_dir->nFiles == MAX_FILES_IN_DIR) {
					res = -ENOSPC;
				}
				if (!res) {
					// Make new file followed by command
					long new_index_block = get_next_free_block(disk_file);
					if (new_index_block > 0) {
						strcpy(sub_dir->files[sub_dir->nFiles].fname, filename);
						strcpy(sub_dir->files[sub_dir->nFiles].fext, extension);
						sub_dir->files[sub_dir->nFiles].nStartBlock = new_index_block;
						sub_dir->nFiles++;

						if (keep_block_disk(disk_file, index_sub_dir_block, sub_dir) || create_bitmap(disk_file, new_index_block, 1)) {
							res = -EIO;
						}
					} else if (new_index_block == -1) {
						res = -ENOSPC;
					} else {
						res = -EIO;
					}
				}
				free(sub_dir);
			}
		}
		free(root_dir);
	}
	close_disk(disk_file);
	return res;
}

/*
 * Deletes a file
 */
static int cs1550_unlink(const char *path)
{
    (void) path;

    return 0;
}

/* 
 * Read size bytes from file into buf starting from offset
 *
 */
static int cs1550_read(const char *path, char *buf, size_t size, off_t offset,
	struct fuse_file_info *fi)
{	//(void) path;
	//(void) buf;
	//(void) offset;
	(void)fi;

	// Check that size is > 0
	if (size == 0) 
		return -EPERM;
	
	char dir[MAX_FILENAME + 1]; 
	char filename[MAX_FILENAME + 1];
	char extension[MAX_EXTENSION + 1];

	int total_path = sscanf(path, "/%[^/]/%[^.].%s", dir, filename, extension);

	if (total_path == EOF) 
		return -EISDIR;

	// Check if dir, filename is too long
	if (strlen(dir) > MAX_FILENAME || strlen(filename) > MAX_FILENAME || strlen(extension) > MAX_EXTENSION) 
		return -ENOENT;

	
	FILE *disk_file = open_disk();
	if (!disk_file) 
		return -ENXIO;

	int res = -ENOENT;
	
	cs1550_root_directory* root_dir = load_root_dir(disk_file);
	if (!root_dir) {
		res = -EIO;
	} else {

		
		size_t index_dir;
		//search for same sub dir name
		for (index_dir = 0; index_dir < root_dir->nDirectories; index_dir++) {
			if (strcmp(root_dir->directories[index_dir].dname, dir) == 0) {
				res = 0;
				break;
			}
		}

		
		if (!res && total_path == 1) {
			
			res = -EISDIR;
		}
		else if (!res && total_path == 2) {
			
			res = -ENOENT; //where is extension?
		}
		else if (!res) {
			res = -ENOENT;
		
			long index_sub_dir_block = root_dir->directories[index_dir].nStartBlock; //try to load sub dir
			cs1550_directory_entry* sub_dir = load_sub_dir(disk_file, index_sub_dir_block);

			if (!sub_dir) {
				res = -EIO;
			} else {
				
				size_t index_file;
				for (index_file = 0; index_file < sub_dir->nFiles; index_file++) {
					if (strcmp(sub_dir->files[index_file].fname, filename) == 0 && strcmp(sub_dir->files[index_file].fext, extension) == 0) {
						res = 0;
						break;
					}
				}
				if (!res) { //if no error
					if (offset > sub_dir->files[index_file].fsize) {
						res = -EFBIG;
					} else {
						
						if (offset + size > sub_dir->files[index_file].fsize) {
							size = sub_dir->files[index_file].fsize - offset;
						}
						
						long index_file_block = sub_dir->files[index_file].nStartBlock; //try to load file block
						cs1550_disk_block* aFile = load_file_block(disk_file, index_file_block);
						
						while (offset > MAX_DATA_IN_BLOCK) {
							if (!aFile || !aFile->nextBlock) {
								res = -EIO;
								break;
							}
							index_file_block = aFile->nextBlock;
							free(aFile);
							aFile = load_file_block(disk_file, index_file_block);
							offset -= MAX_DATA_IN_BLOCK;
						}
						if (!res) {
							
							size_t remaining_size = size;
							while (remaining_size && !res) {

								if (!aFile) {
									res = -EIO;
									break;
								}

								size_t size_to_read = MAX_DATA_IN_BLOCK - offset;
								if (remaining_size < size_to_read) {
									size_to_read = remaining_size;
								}
								
								memcpy(buf, aFile->data + offset, size_to_read); //copy data to block which i am reading

								remaining_size -= size_to_read;
								if (remaining_size && !res) {
									index_file_block = aFile->nextBlock;
									free(aFile);
									aFile = load_file_block(disk_file, index_file_block);
									buf += size_to_read;
									offset = 0;
								}
							}
						}
						if (aFile) 
							free(aFile);
					}
				}
				free(sub_dir);
			}
		}
		free(root_dir);
	}
	close_disk(disk_file);
	return res ? res : size;
}
/* 
 * Write size bytes from buf into file starting from offset
 *
 */
static int cs1550_write(const char *path, const char *buf, size_t size,
	off_t offset, struct fuse_file_info *fi)
{	
	//(void)path;
	//(void)buf;
	//(void)offset;
	//(void)size;

	(void)fi;
	// Check that size is > 0
	if (size == 0) 
		return -EPERM;

	size_t whole_size = size + offset;
	
	char dir[MAX_FILENAME + 1];  
	char filename[MAX_FILENAME + 1];
	char extension[MAX_EXTENSION + 1];
	int total_path = sscanf(path, "/%[^/]/%[^.].%s", dir, filename, extension);

	if (total_path < 3) 
		return -ENOENT;
	//whether file name, dir name is too long
	if (strlen(dir) > MAX_FILENAME || strlen(filename) > MAX_FILENAME || strlen(extension) > MAX_EXTENSION) 
		return -ENOENT;

	
	FILE *disk_file = open_disk();

	if (!disk_file) 
		return -ENXIO;

	int res = -ENOENT;
	
	cs1550_root_directory* root_dir = load_root_dir(disk_file);

	if (!root_dir) {
		res = -EIO;
	} else {
		
		size_t index_dir;
		//search for same sub dir name
		for (index_dir = 0; index_dir < root_dir->nDirectories; index_dir++) {
			if (strcmp(root_dir->directories[index_dir].dname, dir) == 0) {
				res = 0;
				break;
			}
		}
		
		if (!res) { // if no error/
			res = -ENOENT;
			
			long index_sub_dir_block = root_dir->directories[index_dir].nStartBlock;
			cs1550_directory_entry* sub_dir = load_sub_dir(disk_file, index_sub_dir_block);

			if (!sub_dir) {
				res = -EIO;
			} else {
				
				size_t index_file;
				for (index_file = 0; index_file < sub_dir->nFiles; index_file++) {
					if (strcmp(sub_dir->files[index_file].fname, filename) == 0 && strcmp(sub_dir->files[index_file].fext, extension) == 0) {
						res = 0;
						break;
					}
				}
				if (!res) { //if no error and there is file with same name existing
					if (offset > sub_dir->files[index_file].fsize) {
						res = -EFBIG; //offset if bigger than file size
					} else {
						size_t file_write_size = sub_dir->files[index_file].fsize - offset;
						
						long index_file_block = sub_dir->files[index_file].nStartBlock; //try to load file block
						cs1550_disk_block* aFile = load_file_block(disk_file, index_file_block);
					
						while (offset > MAX_DATA_IN_BLOCK) {
							if (!aFile || !aFile->nextBlock) {
								res = -EIO;
								break;
							}
							index_file_block = aFile->nextBlock;
							free(aFile);
							aFile = load_file_block(disk_file, index_file_block);
							offset -= MAX_DATA_IN_BLOCK;
						}
						if (!res) {
							//try to write data to file?
							size_t remaining_size = size;
							long* new_index_block = NULL;
							int used_block = 0;

							if (remaining_size > file_write_size && remaining_size - file_write_size > MAX_DATA_IN_BLOCK - offset) {
								int block_number_prompted = (remaining_size - file_write_size + offset - 1) / MAX_DATA_IN_BLOCK;
								new_index_block = prompt_free_block(disk_file, block_number_prompted);

								if (!new_index_block) 
									res = -ENOSPC;
							}

							while (remaining_size && !res) {

								if (!aFile) {
									res = -EIO;
									break;
								}

								size_t size_to_write = MAX_DATA_IN_BLOCK - offset;

								if (remaining_size < size_to_write) {
									size_to_write = remaining_size;
								}

								// write to file by copying data
								memcpy(aFile->data + offset, buf, size_to_write);

								remaining_size -= size_to_write;

								if (remaining_size && !aFile->nextBlock) {
									
									long next_index_block = *(new_index_block + used_block);
									if (create_bitmap(disk_file, next_index_block, 1)) {
										res = -EIO;
										break;
									}

									aFile->nextBlock = next_index_block;
									used_block++;
								}

								if (keep_block_disk(disk_file, index_file_block, aFile)) {
									res = -EIO;
									break;
								}

								if (remaining_size) {
									index_file_block = aFile->nextBlock;
									free(aFile);
									aFile = load_file_block(disk_file, index_file_block);
									buf += size_to_write;
									offset = 0;
								}
							}

							if (res) {

								int index;
								for (index = 0; index < used_block; index++) {
									create_bitmap(disk_file, *(new_index_block + index), 0);
								}
							}
							if (new_index_block) 
								free(new_index_block);
						}

						if (aFile) 
							free(aFile);

						if (!res && whole_size > sub_dir->files[index_file].fsize) {
							sub_dir->files[index_file].fsize = whole_size;

							if (keep_block_disk(disk_file, index_sub_dir_block, sub_dir)) 
								res = -EIO;
						}
					}
				}
				free(sub_dir);
			}
		}
		free(root_dir);
	}

	close_disk(disk_file);
	return res ? res : size;
}

/******************************************************************************
 *
 *  DO NOT MODIFY ANYTHING BELOW THIS LINE
 *
 *****************************************************************************/

/*
 * truncate is called when a new file is created (with a 0 size) or when an
 * existing file is made shorter. We're not handling deleting files or 
 * truncating existing ones, so all we need to do here is to initialize
 * the appropriate directory entry.
 *
 */
static int cs1550_truncate(const char *path, off_t size)
{
	(void) path;
	(void) size;

    return 0;
}


/* 
 * Called when we open a file
 *
 */
static int cs1550_open(const char *path, struct fuse_file_info *fi)
{
	(void) path;
	(void) fi;
    /*
        //if we can't find the desired file, return an error
        return -ENOENT;
    */

    //It's not really necessary for this project to anything in open

    /* We're not going to worry about permissions for this project, but 
	   if we were and we don't have them to the file we should return an error

        return -EACCES;
    */

    return 0; //success!
}

/*
 * Called when close is called on a file descriptor, but because it might
 * have been dup'ed, this isn't a guarantee we won't ever need the file 
 * again. For us, return success simply to avoid the unimplemented error
 * in the debug log.
 */
static int cs1550_flush (const char *path , struct fuse_file_info *fi)
{
	(void) path;
	(void) fi;

	return 0; //success!
}


//register our new functions as the implementations of the syscalls
static struct fuse_operations hello_oper = {
    .getattr	= cs1550_getattr,
    .readdir	= cs1550_readdir,
    .mkdir	= cs1550_mkdir,
	.rmdir = cs1550_rmdir,
    .read	= cs1550_read,
    .write	= cs1550_write,
	.mknod	= cs1550_mknod,
	.unlink = cs1550_unlink,
	.truncate = cs1550_truncate,
	.flush = cs1550_flush,
	.open	= cs1550_open,
};

//Don't change this.
int main(int argc, char *argv[])
{
	return fuse_main(argc, argv, &hello_oper, NULL);
}
